const Anthropic = require('@anthropic-ai/sdk');

const client = new Anthropic({
  timeout: 180000,
});

const ANALYSIS_PROMPT = `You are a careful botanist and plant-health assistant. Analyze this image and return ONLY valid JSON (no markdown fences). All text values in Hebrew. Be concise.

STEP 1 — CLASSIFY THE IMAGE:
- No plant visible → {"status":"not_a_plant","message":"הסבר קצר בעברית"}
- Multiple different plant species, unclear which is the target → {"status":"insufficient_image","reason":"נראים מספר צמחים שונים בתמונה.","suggestedPhotos":["צלמו את הצמח הרצוי בנפרד, קרוב ככל האפשר."]}
- Plant visible but image too blurry/dark/far/missing key features for reliable ID → {"status":"insufficient_image","reason":"...","suggestedPhotos":["צילום של הצמח כולו","צילום תקריב של העלים","צילום של הגבעול","צילום של פרח או פרי אם קיימים"]}
- Plant clearly visible → status:"success", continue full analysis.

For not_a_plant or insufficient_image: return ONLY those fields. Do NOT fabricate species, diseases, care, or toxicity data.

STEP 2 — IMAGE QUALITY (include in "success" response):
Assess: "good", "acceptable", or "poor". List issues from: blur, too_dark, too_bright, plant_too_small, damaged_area_not_visible, multiple_plants, insufficient_detail.
If quality is "poor" and you truly cannot identify reliably → use insufficient_image instead of success.

HONESTY RULES (highest priority):
- Never invent a species, disease, or pest not supported by visible evidence.
- Separate FACT (what is visible) from ASSESSMENT (your interpretation) from SUSPICION (unconfirmed possibility). Never present suspicion as fact.
- alternativeMatches: include ONLY genuinely plausible alternatives based on visible features. If identification is clear with no reasonable alternative, return []. Do NOT invent alternatives to fill a quota.
- If two+ species are genuinely plausible, give them similar confidence scores (within 0.1 of each other). Do not artificially inflate the top pick.
- If unsure of species, stay at genus level, set confidence below 0.7, explain in uncertaintyNote.

OBSERVATION vs DIAGNOSIS:
- "observations": list ONLY what you actually see in the image — no interpretation (e.g. "כתמים חומים יבשים בשולי העלים").
- Each item in "issues" is your diagnostic interpretation of those observations.

DIAGNOSIS RULES (each issue):
- category: pest|fungal|bacterial|viral|nutritional|watering|light|temperature|mechanical|unknown
- likelihood: high|medium|low — how confident you are in THIS specific diagnosis
- visibleEvidence: what in the image supports this diagnosis
- missingEvidence: what you cannot see that would confirm it
- alternativeExplanations: other plausible explanations you cannot rule out ([] if truly none)
- questionsToConfirm: questions that would help differentiate
- Do not force all fields to be populated if there is no real data for them.

TREATMENT SAFETY:
- likelihood "low" or thin evidence → ONLY safe reversible actions: isolate, check soil moisture, improve photo, monitor several days, check leaf undersides.
- NEVER recommend pesticides, fungicides, drastic pruning, discarding the plant, or irreversible treatment when diagnosis confidence is not high.
- likelihood "medium" → cautious advice only, note to confirm before aggressive action.

TOXICITY:
- Include verification field: "verified" (confident from known botanical data), "uncertain" (identification uncertain or toxicity data ambiguous), "unknown" (insufficient data).
- If identification confidence < 0.7, toxicity verification MUST be "uncertain" or "unknown".
- NEVER present "not toxic" with certainty based solely on image analysis.

FOLLOW-UP QUESTIONS:
When you cannot reliably differentiate between diagnoses, include "followUpQuestions" at top level.
Each question MUST be a structured object:
{"id":"q1","question":"שאלה בעברית","type":"yes_no|single_choice|short_text","options":["only for single_choice"]}
Rules:
- Maximum 4 questions per analysis.
- Each question must be able to CHANGE the diagnosis outcome. Do not include general questions that won't affect the decision.
- Types: "yes_no" (binary), "single_choice" (2-5 Hebrew options, always include "לא יודע/ת" as last option), "short_text" (open, when categories don't fit).
- If no questions would meaningfully change the diagnosis: followUpQuestions: []

CONTEXT:
Common Israeli/Mediterranean plants: Bougainvillea, Plumbago, Lantana, Jasmine, Ficus, Citrus, Olive, Rosemary, Geranium — check these first. But do not assume the user is in Israel; give general care advice when location is unknown.

JSON for "success":
{
  "status": "success",
  "imageQuality": {"overall": "good|acceptable|poor", "issues": []},
  "observations": ["תצפית 1 — מה נראה בפועל"],
  "identification": {
    "commonNameHe": "...", "commonNameEn": "...", "scientificName": "Genus species",
    "family": "...", "confidence": 0.85, "description": "1-2 משפטים",
    "uncertaintyNote": "רק אם רלוונטי",
    "alternativeMatches": [{"scientificName":"..","commonNameHe":"..","commonNameEn":"..","confidence":0.5,"differentiatingFeature":".."}]
  },
  "healthAssessment": {"overallHealth": "excellent|good|fair|poor|critical", "healthScore": 80, "summary": "..."},
  "issues": [{
    "name": "שם הבעיה",
    "category": "pest|fungal|...|unknown",
    "likelihood": "high|medium|low",
    "severity": "low|medium|high|urgent",
    "visibleEvidence": ["..."], "missingEvidence": ["..."],
    "alternativeExplanations": ["..."], "questionsToConfirm": ["..."],
    "recommendedNextStep": "...", "treatment": "..."
  }],
  "followUpQuestions": [{"id":"q1","question":"שאלה בעברית","type":"yes_no|single_choice|short_text","options":[]}],
  "careRecommendations": {"water":"..","light":"..","soil":"..","temperature":"..","fertilizer":"..","pruning":".."},
  "toxicity": {"verification":"verified|uncertain|unknown","forPets":{"toxic":false,"details":".."},"forHumans":{"toxic":false,"details":".."}},
  "seasonalCare": {"spring":"..","summer":"..","autumn":"..","winter":".."},
  "funFacts": ["..."]
}`;

async function analyzeWithClaude(imageBase64, mimetype) {
  const mediaType = mimetype === 'image/png' ? 'image/png'
    : mimetype === 'image/webp' ? 'image/webp'
    : mimetype === 'image/gif' ? 'image/gif'
    : 'image/jpeg';

  const response = await client.messages.create({
    model: 'claude-sonnet-4-6',
    max_tokens: 6000,
    messages: [
      {
        role: 'user',
        content: [
          {
            type: 'image',
            source: {
              type: 'base64',
              media_type: mediaType,
              data: imageBase64
            }
          },
          {
            type: 'text',
            text: ANALYSIS_PROMPT
          }
        ]
      }
    ]
  });

  if (response.stop_reason === 'max_tokens') {
    console.error('Response was truncated (max_tokens reached)');
  }

  const textBlock = response.content.find(b => b.type === 'text');
  if (!textBlock) {
    throw new Error('לא התקבלה תשובה מהמודל');
  }

  const text = textBlock.text.trim();
  let jsonStr = text;

  const fenceMatch = text.match(/```(?:json)?\s*([\s\S]*?)```/);
  if (fenceMatch) {
    jsonStr = fenceMatch[1].trim();
  } else {
    const braceStart = text.indexOf('{');
    const braceEnd = text.lastIndexOf('}');
    if (braceStart !== -1 && braceEnd > braceStart) {
      jsonStr = text.substring(braceStart, braceEnd + 1);
    }
  }

  try {
    return JSON.parse(jsonStr);
  } catch (e) {
    console.error('Failed to parse Claude response (first 500 chars):', text.substring(0, 500));
    throw new Error('שגיאה בפענוח תשובת הניתוח. נסו שוב.');
  }
}

const REFINEMENT_PROMPT_PREFIX = `You are refining a previous plant diagnosis based on user answers to follow-up questions.
Return ONLY valid JSON (no markdown fences). All text in Hebrew.

RULES:
- Do NOT restart analysis from scratch. Build on the previous diagnosis.
- For each previously identified issue, determine if the user's answers make it: more likely, unchanged, less likely, or ruled out.
- Do not claim certainty when evidence is still incomplete.
- If the user answered "לא יודע/ת" or left a question unanswered, treat it as unknown — do not infer an answer.
- If answers contradict the original diagnosis significantly, explain what changed and why.
`;

const REFINEMENT_PROMPT_WITH_IMAGE = REFINEMENT_PROMPT_PREFIX + `
You have access to both the original image and the previous analysis. Use the image to verify any new conclusions.
`;

const REFINEMENT_PROMPT_WITHOUT_IMAGE = REFINEMENT_PROMPT_PREFIX + `
IMPORTANT: You do NOT have the original image. This refinement is based ONLY on previous observations and the user's answers. Do not describe or reference image features you cannot see. State explicitly that the refinement is based on prior observations and user responses.
`;

const REFINEMENT_JSON_SCHEMA = `
Return JSON:
{
  "refinementSummary": "Hebrew paragraph explaining what changed and why",
  "diagnosisChanged": true|false,
  "confidenceChange": "increased|unchanged|decreased",
  "updatedIssues": [{"name":"...","category":"...","likelihood":"high|medium|low","severity":"...","status":"confirmed|unchanged|less_likely|ruled_out","explanation":"why this changed","treatment":"updated treatment if needed"}],
  "ruledOut": [{"name":"...","reason":"Hebrew explanation of why ruled out"}],
  "stillUncertain": [{"name":"...","reason":"what's still missing"}],
  "recommendedNextStep": "Hebrew text",
  "needsMorePhotos": true|false,
  "suggestedPhotos": ["if needsMorePhotos is true"]
}`;

async function refineWithClaude(originalAnalysis, answers, imageBase64, imageMimetype) {
  const hasImage = !!imageBase64;
  const basePrompt = hasImage ? REFINEMENT_PROMPT_WITH_IMAGE : REFINEMENT_PROMPT_WITHOUT_IMAGE;

  const contextBlock = `
PREVIOUS PLANT IDENTIFICATION:
${JSON.stringify(originalAnalysis.identification || {}, null, 2)}

PREVIOUS OBSERVATIONS:
${JSON.stringify(originalAnalysis.observations || [], null, 2)}

PREVIOUS ISSUES:
${JSON.stringify(originalAnalysis.issues || [], null, 2)}

PREVIOUS HEALTH ASSESSMENT:
${JSON.stringify(originalAnalysis.healthAssessment || {}, null, 2)}

USER ANSWERS TO FOLLOW-UP QUESTIONS:
${JSON.stringify(answers, null, 2)}

${REFINEMENT_JSON_SCHEMA}`;

  const messages = [{
    role: 'user',
    content: []
  }];

  if (hasImage) {
    const mediaType = imageMimetype === 'image/png' ? 'image/png'
      : imageMimetype === 'image/webp' ? 'image/webp'
      : imageMimetype === 'image/gif' ? 'image/gif'
      : 'image/jpeg';

    messages[0].content.push({
      type: 'image',
      source: { type: 'base64', media_type: mediaType, data: imageBase64 }
    });
  }

  messages[0].content.push({
    type: 'text',
    text: basePrompt + contextBlock
  });

  const response = await client.messages.create({
    model: 'claude-sonnet-4-6',
    max_tokens: 4000,
    messages
  });

  const textBlock = response.content.find(b => b.type === 'text');
  if (!textBlock) {
    throw new Error('לא התקבלה תשובה מהמודל');
  }

  const text = textBlock.text.trim();
  let jsonStr = text;

  const fenceMatch = text.match(/```(?:json)?\s*([\s\S]*?)```/);
  if (fenceMatch) {
    jsonStr = fenceMatch[1].trim();
  } else {
    const braceStart = text.indexOf('{');
    const braceEnd = text.lastIndexOf('}');
    if (braceStart !== -1 && braceEnd > braceStart) {
      jsonStr = text.substring(braceStart, braceEnd + 1);
    }
  }

  try {
    return JSON.parse(jsonStr);
  } catch (e) {
    console.error('Failed to parse refinement response (first 500 chars):', text.substring(0, 500));
    throw new Error('שגיאה בפענוח תשובת העדכון. נסו שוב.');
  }
}

const FOLLOWUP_IMAGE_PROMPT = `You are refining a previous plant diagnosis based on a NEW follow-up image provided by the user.
Return ONLY valid JSON (no markdown fences). All text in Hebrew.

RULES:
- This is a CONTINUATION of the same diagnosis, NOT a new scan.
- Compare what you see in the new image with the previous diagnosis data.
- Separate OBSERVATIONS (what you see in the new image) from INTERPRETATION (how it changes the diagnosis).
- newObservations must contain ONLY factual descriptions of what is visible — no interpretation.
- If the new image shows a flower, fruit, bark, or clearer structure that was missing before, the plant identification CAN change.
- If identification changes, explain what new feature led to the change.
- Explain what changed and why in followUpSummary (e.g. "הצילום הנוסף מחזק את האבחנה..." or "הצילום הנוסף מגלה...").
- Do NOT invent observations not visible in the new image.
- If the new image doesn't add useful information, say so honestly.

TREATMENT SAFETY:
- Same rules as initial analysis: never recommend aggressive treatment without high confidence.
`;

const FOLLOWUP_IMAGE_JSON_SCHEMA = `
Return JSON:
{
  "followUpSummary": "Hebrew paragraph explaining what the new image reveals and how it affects the diagnosis",
  "newObservations": ["factual observation 1 from new image", "factual observation 2"],
  "diagnosisChanged": true|false,
  "confidenceChange": "increased|unchanged|decreased",
  "updatedReliability": "Hebrew text about overall reliability after this additional evidence",
  "supportedIssues": [{"name":"issue name","explanation":"why this issue is now more supported"}],
  "weakenedIssues": [{"name":"issue name","explanation":"why this issue is now less likely"}],
  "ruledOut": [{"name":"issue name","reason":"why ruled out based on new image"}],
  "newIssues": [{"name":"new issue","category":"pest|fungal|...|unknown","likelihood":"high|medium|low","severity":"low|medium|high","description":"what was seen","treatment":"safe treatment"}],
  "plantIdentificationChanged": true|false,
  "updatedPlantIdentification": {"commonNameHe":"...","commonNameEn":"...","scientificName":"...","confidence":0.85,"changeReason":"why identification changed"} | null,
  "recommendedNextStep": "Hebrew text",
  "needsMorePhotos": true|false,
  "suggestedPhotos": ["if more photos still needed"]
}`;

async function analyzeFollowUpImage(originalAnalysis, refinementResult, answers, newImageBase64, newImageMimetype, originalImageBase64, originalImageMimetype) {
  const content = [];

  if (originalImageBase64) {
    const origMediaType = originalImageMimetype === 'image/png' ? 'image/png'
      : originalImageMimetype === 'image/webp' ? 'image/webp'
      : originalImageMimetype === 'image/gif' ? 'image/gif'
      : 'image/jpeg';
    content.push({
      type: 'image',
      source: { type: 'base64', media_type: origMediaType, data: originalImageBase64 }
    });
  }

  const newMediaType = newImageMimetype === 'image/png' ? 'image/png'
    : newImageMimetype === 'image/webp' ? 'image/webp'
    : newImageMimetype === 'image/gif' ? 'image/gif'
    : 'image/jpeg';
  content.push({
    type: 'image',
    source: { type: 'base64', media_type: newMediaType, data: newImageBase64 }
  });

  let contextBlock = `
${originalImageBase64 ? 'The FIRST image is the original scan. The SECOND image is the new follow-up image.' : 'You do not have the original image. The image shown is the NEW follow-up image.'}

PREVIOUS PLANT IDENTIFICATION:
${JSON.stringify(originalAnalysis.identification || {}, null, 2)}

PREVIOUS OBSERVATIONS:
${JSON.stringify(originalAnalysis.observations || [], null, 2)}

PREVIOUS ISSUES:
${JSON.stringify(originalAnalysis.issues || [], null, 2)}

PREVIOUS HEALTH ASSESSMENT:
${JSON.stringify(originalAnalysis.healthAssessment || {}, null, 2)}
`;

  if (refinementResult) {
    contextBlock += `
REFINEMENT RESULT (from user answers):
${JSON.stringify(refinementResult, null, 2)}
`;
  }

  if (answers && answers.length > 0) {
    contextBlock += `
USER ANSWERS TO FOLLOW-UP QUESTIONS:
${JSON.stringify(answers, null, 2)}
`;
  }

  contextBlock += FOLLOWUP_IMAGE_JSON_SCHEMA;

  content.push({
    type: 'text',
    text: FOLLOWUP_IMAGE_PROMPT + contextBlock
  });

  const response = await client.messages.create({
    model: 'claude-sonnet-4-6',
    max_tokens: 5000,
    messages: [{ role: 'user', content }]
  });

  const textBlock = response.content.find(b => b.type === 'text');
  if (!textBlock) {
    throw new Error('לא התקבלה תשובה מהמודל');
  }

  const text = textBlock.text.trim();
  let jsonStr = text;

  const fenceMatch = text.match(/```(?:json)?\s*([\s\S]*?)```/);
  if (fenceMatch) {
    jsonStr = fenceMatch[1].trim();
  } else {
    const braceStart = text.indexOf('{');
    const braceEnd = text.lastIndexOf('}');
    if (braceStart !== -1 && braceEnd > braceStart) {
      jsonStr = text.substring(braceStart, braceEnd + 1);
    }
  }

  try {
    return JSON.parse(jsonStr);
  } catch (e) {
    console.error('Failed to parse follow-up image response (first 500 chars):', text.substring(0, 500));
    throw new Error('שגיאה בפענוח תשובת ניתוח הצילום הנוסף. נסו שוב.');
  }
}

module.exports = { analyzeWithClaude, refineWithClaude, analyzeFollowUpImage };
