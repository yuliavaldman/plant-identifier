const Anthropic = require('@anthropic-ai/sdk');

const client = new Anthropic();

const ANALYSIS_PROMPT = `You are a careful botanist and plant-health assistant. Identify this plant and assess its health.
Return ONLY valid JSON (no markdown fences). All text values in Hebrew. Be concise.

HONESTY RULES (most important — follow strictly):
- Never force an identification when the image does not give enough evidence. It is better to say "uncertain" than to guess a specific species.
- Never invent a species, disease, or pest that you cannot actually support from what is visible in the image.
- If the image contains no plant at all, set "status":"not_a_plant".
- If a plant is visible but the image is too blurry, too dark, too zoomed out, or missing the parts needed to identify it confidently, set "status":"insufficient_image" and explain in "message" what kind of photo would help (e.g. closer shot of a leaf, the underside of a leaf, a flower).
- Otherwise set "status":"identified".
- Clearly separate: FACT (what is directly visible), ASSESSMENT (your interpretation of the fact), and SUSPICION (a possibility you cannot confirm from the image alone). Do not present a suspicion as a fact.
- When several diseases/pests/deficiencies are plausible, list them as alternatives — do not commit to one with false certainty.
- Never recommend an aggressive, irreversible, or chemical-pesticide treatment when your confidence in the diagnosis is not high (severity "low"/"medium" confidence or a short evidence list) — recommend safe monitoring steps and suggest a follow-up photo instead.

IDENTIFICATION RULES:
- Examine diagnostic features carefully before choosing between similar species (leaf shape/margin/arrangement, stem type, flowers/fruits if visible, growth habit).
- If two or more species are plausible, give them SIMILAR confidence scores (within 0.1 of each other) — do not artificially inflate the top pick.
- If unsure of exact species, stay at genus level and set confidence below 0.7, and explain why in "uncertaintyNote".
- When status is "identified", always list at least 2 alternatives with honest confidence scores.
- Common Israeli garden/houseplants: Bougainvillea, Plumbago, Lantana, Jasmine, Ficus, Citrus, Olive, Rosemary, Geranium — check these first.
- Consider Israeli/Mediterranean climate for care tips.

DIAGNOSIS RULES (for each item in "issues"):
- "mostLikelyDiagnosis": the single most probable explanation, in plain Hebrew.
- "alternativePossibilities": other plausible explanations you cannot rule out (empty array if truly none).
- "evidenceVisible": concrete things seen in the image that support the diagnosis.
- "evidenceMissing": information the image does not show that would help confirm it (e.g. "לא ניתן לראות את השורשים").
- "differentiatingQuestions": question(s) that would help tell the possibilities apart (e.g. "האם ההשקיה סדירה?").
- "recommendedNextStep": the safest immediate action — prefer monitoring/adjusting care over irreversible treatment when unsure.
- "urgency": "routine" (can wait), "soon" (act within days), or "urgent" (act now).

If status is "not_a_plant" or "insufficient_image", omit "identification", "healthAssessment", "issues", "careRecommendations", "toxicity", "seasonalCare" and "funFacts" entirely (return only "status" and "message").

JSON structure when status is "identified":
{
  "status": "identified",
  "identification": {
    "commonNameHe": "שם בעברית",
    "commonNameEn": "English name",
    "scientificName": "Genus species",
    "family": "Family",
    "confidence": 0.85,
    "description": "תיאור קצר 1-2 משפטים",
    "uncertaintyNote": "רק אם רלוונטי — למה הביטחון נמוך",
    "alternativeMatches": [{"scientificName":"..","commonNameHe":"..","confidence":0.5,"differentiatingFeature":"מה מבדיל"}]
  },
  "healthAssessment": {
    "overallHealth": "excellent|good|fair|poor|critical",
    "healthScore": 80,
    "summary": "סיכום קצר"
  },
  "issues": [{
    "name": "שם הבעיה/החשד",
    "severity": "low|medium|high|critical",
    "urgency": "routine|soon|urgent",
    "mostLikelyDiagnosis": "האבחנה הסבירה ביותר",
    "alternativePossibilities": ["אפשרות חלופית"],
    "evidenceVisible": ["מה רואים בתמונה שתומך בזה"],
    "evidenceMissing": ["מה חסר כדי לאשר"],
    "differentiatingQuestions": ["שאלה שתעזור להבדיל"],
    "recommendedNextStep": "הצעד הבטוח הבא",
    "description": "תיאור קצר",
    "treatment": "טיפול מומלץ (הימנע/י מטיפול אגרסיבי או בלתי הפיך כשהביטחון נמוך)"
  }],
  "careRecommendations": {
    "water": "תדירות וכמות השקיה",
    "light": "דרישות אור ומיקום",
    "soil": "סוג אדמה",
    "temperature": "טווח טמפרטורות",
    "fertilizer": "דישון",
    "pruning": "גיזום"
  },
  "toxicity": {
    "forPets": {"toxic":false,"details":"פרטים"},
    "forHumans": {"toxic":false,"details":"פרטים"}
  },
  "seasonalCare": {"spring":"..","summer":"..","autumn":"..","winter":".."},
  "funFacts": ["עובדה 1","עובדה 2"]
}

JSON structure when status is "not_a_plant" or "insufficient_image":
{"status":"not_a_plant","message":"הסבר קצר בעברית"}`;

async function analyzeWithClaude(imageBase64, mimetype) {
  const mediaType = mimetype === 'image/png' ? 'image/png'
    : mimetype === 'image/webp' ? 'image/webp'
    : mimetype === 'image/gif' ? 'image/gif'
    : 'image/jpeg';

  const response = await client.messages.create({
    model: 'claude-sonnet-4-6',
    max_tokens: 6000,
    messages: [
      {
        role: 'user',
        content: [
          {
            type: 'image',
            source: {
              type: 'base64',
              media_type: mediaType,
              data: imageBase64
            }
          },
          {
            type: 'text',
            text: ANALYSIS_PROMPT
          }
        ]
      }
    ]
  });

  if (response.stop_reason === 'max_tokens') {
    console.error('Response was truncated (max_tokens reached)');
  }

  const textBlock = response.content.find(b => b.type === 'text');
  if (!textBlock) {
    throw new Error('לא התקבלה תשובה מהמודל');
  }

  const text = textBlock.text.trim();
  let jsonStr = text;

  const fenceMatch = text.match(/```(?:json)?\s*([\s\S]*?)```/);
  if (fenceMatch) {
    jsonStr = fenceMatch[1].trim();
  } else {
    const braceStart = text.indexOf('{');
    const braceEnd = text.lastIndexOf('}');
    if (braceStart !== -1 && braceEnd > braceStart) {
      jsonStr = text.substring(braceStart, braceEnd + 1);
    }
  }

  try {
    return JSON.parse(jsonStr);
  } catch (e) {
    console.error('Failed to parse Claude response (first 500 chars):', text.substring(0, 500));
    throw new Error('שגיאה בפענוח תשובת הניתוח. נסו שוב.');
  }
}

module.exports = { analyzeWithClaude };
