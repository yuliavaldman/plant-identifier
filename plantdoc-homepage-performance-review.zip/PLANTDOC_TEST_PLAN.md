# PlantDoc — Test Plan

Manual/functional test plan for the plant identification, diagnosis and reliability behavior of the app.
Each case should be run by uploading the described image via the real UI (or `POST /api/analyze` + poll `/api/result/:jobId`) against a deployed or local instance with a valid `ANTHROPIC_API_KEY`.

Status values referenced below come from the Claude response schema in [services/claude-vision.js](services/claude-vision.js): `identified`, `insufficient_image`, `not_a_plant`.

## How to record results

For each run, log: date, image used, `status` returned, primary identification (if any) + `confidenceLevel`, whether `issues` used the new diagnosis fields, and whether Pass/Fail criteria were met.

---

### 1. Healthy plant
**Input:** Clear, well-lit photo of a plant with no visible damage.
**Expected behaviour:** `status: identified`, high/medium confidenceLevel, `healthAssessment.overallHealth` in `excellent|good`, `issues` empty or very minor.
**Pass:** Species plausible for the photo; no fabricated disease; `issues` array is empty or lists only low-severity/routine items with real evidence.
**Fail:** A disease/pest is invented with no visible evidence; species wildly wrong with high confidence.

### 2. Common houseplant
**Input:** Photo of a typical indoor plant (e.g. pothos, ficus, succulent).
**Expected behaviour:** `identified`, reasonable species/genus match, care recommendations relevant to indoor conditions.
**Pass:** commonNameHe/scientificName plausible; careRecommendations not generic filler.
**Fail:** Confused with an unrelated outdoor species; care advice contradicts the plant type (e.g. "מיקום מוצל" for a full-sun cactus).

### 3. Garden plant
**Input:** Outdoor ornamental (e.g. Bougainvillea, Lantana, Plumbago).
**Expected behaviour:** `identified`; matches the "common Israeli garden plants" list in the prompt when applicable.
**Pass:** Correct genus at minimum; seasonalCare.israelSpecific present and relevant.
**Fail:** Misidentifies a common local ornamental as an exotic/rare species.

### 4. Tree
**Input:** Photo of a tree trunk + canopy/leaves.
**Expected behaviour:** `identified` at genus level acceptable if species-level features (fruit/flower) aren't visible; `uncertaintyNote` explains if species is uncertain.
**Pass:** Genus correct; confidence appropriately lowered (below 0.7) if species can't be confirmed.
**Fail:** Confident species-level claim without visible diagnostic features (flower/fruit/bark detail).

### 5. Vegetable
**Input:** Vegetable plant (e.g. tomato, pepper) in soil or pot.
**Expected behaviour:** `identified`; care recommendations agriculturally sensible (watering, fertilizer).
**Pass:** Correct plant family at least; no toxicity false-positive for an edible.
**Fail:** Edible vegetable flagged as toxic without basis.

### 6. Flower
**Input:** Close-up of a single flower/bloom.
**Expected behaviour:** `identified`, may lean on flower morphology for higher confidence.
**Pass:** Species/genus plausible from flower shape/color/petal count described.
**Fail:** Ignores flower and guesses from leaf shape alone with high confidence.

### 7. Plant with fungal disease
**Input:** Leaf with visible fungal spots/mildew/rust.
**Expected behaviour:** `identified`; `issues` includes an item with `mostLikelyDiagnosis` naming a fungal-type issue, `evidenceVisible` describing the spots/pattern, `alternativePossibilities` listing at least one other explanation (e.g. nutrient deficiency, sunburn) unless visually unambiguous.
**Pass:** Diagnosis structure fully populated (mostLikelyDiagnosis, evidenceVisible, recommendedNextStep, urgency); no pesticide brand names; treatment doesn't recommend an aggressive/irreversible step given photo-only evidence.
**Fail:** Names a specific fungal species with false certainty; recommends chemical treatment as the only option; `alternativePossibilities` missing when diagnosis is genuinely ambiguous from a single photo.

### 8. Plant with pest damage
**Input:** Leaves with chew marks, webbing, or visible insects.
**Expected behaviour:** `identified`; issue evidence should reference the visible damage pattern (holes, webbing, discoloration), not assume a specific pest species unless visible.
**Pass:** `evidenceVisible` ties directly to what's in the photo; `differentiatingQuestions` offered if the pest itself isn't visible.
**Fail:** Names a specific insect species with no insect visible in the photo.

### 9. Nutrient deficiency
**Input:** Interveinal yellowing / leaf discoloration pattern typical of a deficiency.
**Expected behaviour:** `identified`; `issues` distinguishes deficiency from overwatering/underwatering as `alternativePossibilities` since these often look similar.
**Pass:** `differentiatingQuestions` includes something like watering frequency or fertilizer history.
**Fail:** Commits to one specific nutrient (e.g. "מחסור באבץ") with high certainty from color alone, with no hedge.

### 10. Sunburn
**Input:** Leaf with bleached/scorched patches, typically on the sun-facing side.
**Expected behaviour:** `identified`; diagnosis references patch location/pattern; `urgency` should be "routine" or "soon", not "urgent" (sunburn on an otherwise-healthy plant is not an emergency).
**Pass:** Reasonable non-aggressive recommendedNextStep (shade adjustment, monitoring).
**Fail:** Recommends drastic pruning or chemical treatment for cosmetic sun damage.

### 11. Overwatering
**Input:** Yellowing lower leaves, soft/mushy stem, waterlogged soil visible.
**Expected behaviour:** `identified`; evidenceMissing should note that root condition can't be seen from a leaf/canopy photo.
**Pass:** recommendedNextStep is a safe check (e.g. check soil moisture/drainage) not an irreversible action.
**Fail:** Diagnoses root rot with certainty from a photo that doesn't show roots.

### 12. Underwatering
**Input:** Wilted, crispy, drooping leaves; dry visible soil.
**Expected behaviour:** `identified`; distinguishes from disease in `alternativePossibilities` if ambiguous.
**Pass:** Care/treatment recommends gradual rehydration, not shock actions.
**Fail:** N/A criteria contradicted (e.g. recommends reducing water for a clearly underwatered plant).

### 13. Mechanical damage
**Input:** Torn/broken leaf or snapped stem from physical damage (not disease).
**Expected behaviour:** `identified`; issue correctly attributes damage to mechanical cause, not disease, when the damage pattern is clearly a clean tear/break rather than organic spread.
**Pass:** Does not invent a pathogen for clearly physical damage.
**Fail:** Labels a torn leaf as a fungal/bacterial infection.

### 14. Dead plant
**Input:** Fully brown/dry/dead plant material.
**Expected behaviour:** `identified` (it is still recognizable plant matter) with `healthAssessment.overallHealth: critical` or similar; should NOT return `not_a_plant`.
**Pass:** healthScore very low; issues/recommendedNextStep acknowledges the plant may not be salvageable rather than suggesting routine care.
**Fail:** Returns `not_a_plant` for dead-but-recognizable plant material, or gives upbeat healthy-plant care tips.

### 15. Dry leaf (single leaf, detached)
**Input:** A single dried/pressed leaf, no plant context.
**Expected behaviour:** Depends on how identifiable the leaf shape is — `identified` at genus level with lowered confidence, or `insufficient_image` if truly not enough to go on.
**Pass:** Confidence appropriately low; doesn't claim species-level certainty from one dry leaf alone.
**Fail:** High-confidence species claim from a single ambiguous dry leaf.

### 16. Plastic/artificial plant
**Input:** Photo of a fake plastic/silk plant.
**Expected behaviour:** Ideally `not_a_plant` or `insufficient_image` with a message noting it looks artificial; acceptable fallback is `identified` with an explicit `uncertaintyNote` flagging it may not be a real plant.
**Pass:** Does not produce a confident health/disease assessment for an artificial object.
**Fail:** Full health diagnosis (health score, watering advice, disease detection) on a plastic plant with no caveat.

### 17. Fruit without plant (fruit on a table/counter)
**Input:** Cut or whole fruit with no surrounding plant/leaves.
**Expected behaviour:** `insufficient_image` (fruit alone, no leaves/stem/growth habit visible) — model should ask for a photo of the plant itself.
**Pass:** Message explains that plant-level features (leaves/stem) are needed, not just the fruit.
**Fail:** Confidently identifies species and gives full care/health assessment from fruit alone.

### 18. Animal
**Input:** Photo of an animal (pet, bird, etc.), no plant.
**Expected behaviour:** `status: not_a_plant`.
**Pass:** Clear `not_a_plant` with sensible message; no plant fields returned.
**Fail:** Any plant identification attempted.

### 19. Furniture / random object
**Input:** Photo of furniture, a wall, a phone, etc.
**Expected behaviour:** `status: not_a_plant`.
**Pass:** Same as #18.
**Fail:** Same as #18.

### 20. Completely blurred image
**Input:** Heavily out-of-focus photo where no shapes are distinguishable.
**Expected behaviour:** `status: insufficient_image`, message asks for a clearer/closer photo.
**Pass:** Model does not guess a species from an unreadable image.
**Fail:** Any specific species/disease claim from an indecipherable blur.

### 21. Extremely dark image
**Input:** Underexposed/near-black photo.
**Expected behaviour:** `status: insufficient_image`, message references poor lighting/visibility.
**Pass:** Same as #20.
**Fail:** Same as #20.

### 22. Multiple plant species in one photo
**Input:** A garden bed or mixed planter with 2+ clearly different species.
**Expected behaviour:** `identified` for the most prominent/central plant, ideally with `uncertaintyNote` or `message` acknowledging multiple species are present and only one was assessed.
**Pass:** Response is coherent about one plant rather than a confused blend of traits from multiple species.
**Fail:** Merges features from different plants into one impossible description.

### 23. Rare/unusual plant
**Input:** An uncommon species unlikely to be well-represented in training data.
**Expected behaviour:** `identified` at a conservative level (genus/family) with confidence below 0.6-0.7 and `uncertaintyNote`, OR `insufficient_image` if truly unrecognizable — NOT a confident specific-species guess.
**Pass:** Confidence honestly reflects uncertainty; alternatives offered.
**Fail:** High-confidence specific species claim for an obscure plant with no real basis.

### 24. Two visually similar species
**Input:** A plant from a pair/group known to be easily confused (e.g. two Ficus species, two citrus varieties).
**Expected behaviour:** `identified`; `alternativeMatches` includes the confusable species with a confidence score close to the primary (within ~0.1) per the prompt's explicit rule, and `differentiatingFeature` explains what would distinguish them.
**Pass:** Alternative confidence is genuinely close (not artificially low just to satisfy the format); differentiatingFeature is a real distinguishing trait, not generic text.
**Fail:** Alternative listed with token confidence (e.g. 0.1) that doesn't reflect real ambiguity, or no meaningful differentiatingFeature.

---

## Cross-cutting checks (apply to every case above)

- Confidence is shown to the user as a word ("רמת אמינות גבוהה/בינונית/נמוכה"), never as a bare "X% probability" implying scientific certainty.
- When PlantNet and/or Wikipedia disagree with Claude's primary identification, the UI shows the literal warning: "הזיהוי אינו ודאי. מומלץ לצלם תמונה נוספת מזווית אחרת."
- No aggressive/irreversible treatment (pesticide, drastic pruning, discarding the plant) is recommended when the issue's evidence is thin or confidence is low.
- Error responses (bad file, oversized file, corrupt image, server error) never leak stack traces, file paths, or library error text to the client.
- Repeated rapid requests from the same client are rate-limited (429) rather than silently costing API calls indefinitely.

## Known test gaps (not yet run)

This plan has not yet been executed against real photographs for cases #1–#15 and #22–#24 (they require actual plant/disease photos, which were not available in the environment used to build this feature). Cases #16–#21 involving non-plant/degraded images, and the not-a-plant/insufficient-image status logic in general, **were** validated against the live Claude API — see the implementation summary for results. Before relying on this in front of real users, run at least one real photo through cases #1, #7, #17, #20 and #24 to confirm the diagnosis-field rendering and disagreement-warning UI look right end-to-end.
